$ = jQuery = require('jquery');
var App = console.log('Hello world from Browserify');

module.exports = App;
